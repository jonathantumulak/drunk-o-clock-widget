const SoberSwears = ['flippin','frikkin','freakin','darnit','bangin','truckin','crappin']
const SoberWords = ['Ohh', 'Blimey', 'Hell', 'Flip', 'Eek', 'Oo-er'];

const TipsySwears = ['shitting', 'cocking', 'twattin', 'jizzing', 'pissing', 'bastard']
const TipsyWords = ['Arse','Ass','Balls','Piss','Bitch','Wank']

const WastedSwears = ['wanking', 'shagging', 'fucking', 'bitching']
const WastedWords = ['Shit', 'Faggot', 'Dick', 'Whore', 'Douche', 'Cunt', 'Fuck', 'Mofo']

export const Swears = SoberSwears.concat(TipsySwears, WastedSwears);
export const Words = SoberWords.concat(TipsyWords, WastedWords);
