export const Multiples = ["ten", "twenty", "thirty", "forty", "fifty", "sixty"];
export const Digits = ["one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve"];
export const Tens = ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"];
export const Days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];